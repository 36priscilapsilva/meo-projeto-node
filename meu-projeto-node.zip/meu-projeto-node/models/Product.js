const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    nome: { type: String, required: true },
    descricao: { type: String, required: true },
    preco: { type: Number, required: true },
    quantidade: { type: Number, required: true },
    categoria: { type: String, required: true }
}, {
    timestamps: true // Adiciona os campos `createdAt` e `updatedAt`
});

const Product = mongoose.model('Product', productSchema);

module.exports = Product;