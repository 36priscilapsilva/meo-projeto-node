const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config(); // Carrega variáveis de ambiente do arquivo .env

const app = express();

// Middlewares
app.use(bodyParser.json());
app.use(cors());

// Conexão ao MongoDB Atlas
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('Conectado ao MongoDB Atlas'))
.catch(err => console.error('Erro ao conectar ao MongoDB Atlas', err));

// Importa as rotas
const productRoutes = require('./routes/productRoutes');

// Define as rotas
app.use('/api/products', productRoutes);

// Inicia o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});