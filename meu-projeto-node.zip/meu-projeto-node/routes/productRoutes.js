const express = require('express');
const router = express.Router();
const Product = require('../models/Product');

// Criar um novo produto (Create)
router.post('/', async (req, res) => {
    try {
        const { nome, descricao, preco, quantidade, categoria } = req.body;
        const newProduct = new Product({ nome, descricao, preco, quantidade, categoria });
        await newProduct.save();
        res.status(201).json(newProduct);
    } catch (error) {
        res.status(500).json({ message: 'Erro ao criar o produto', error });
    }
});

// Listar todos os produtos (Read)
router.get('/', async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);
    } catch (error) {
        res.status(500).json({ message: 'Erro ao listar os produtos', error });
    }
});

// Obter um produto específico (Read)
router.get('/:id', async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).json({ message: 'Produto não encontrado' });
        }
        res.status(200).json(product);
    } catch (error) {
        res.status(500).json({ message: 'Erro ao obter o produto', error });
    }
});

// Atualizar um produto específico (Update)
router.put('/:id', async (req, res) => {
    try {
        const { nome, descricao, preco, quantidade, categoria } = req.body;
        const updatedProduct = await Product.findByIdAndUpdate(
            req.params.id,
            { nome, descricao, preco, quantidade, categoria },
            { new: true }
        );
        if (!updatedProduct) {
            return res.status(404).json({ message: 'Produto não encontrado' });
        }
        res.status(200).json(updatedProduct);
    } catch (error) {
        res.status(500).json({ message: 'Erro ao atualizar o produto', error });
    }
});

// Excluir um produto específico (Delete)
router.delete('/:id', async (req, res) => {
    try {
        const deletedProduct = await Product.findByIdAndDelete(req.params.id);
        if (!deletedProduct) {
            return res.status(404).json({ message: 'Produto não encontrado' });
        }
        res.status(200).json({ message: 'Produto excluído com sucesso' });
    } catch (error) {
        res.status(500).json({ message: 'Erro ao excluir o produto', error });
    }
});

module.exports = router;